/* 
 * File:   PuzzleHandler.cpp
 * Author: patricklangille
 * 
 * Created on September 27, 2017, 8:05 PM
 */

#include "PuzzleHandler.h"

/**
 * Description: initializes the number of puzzle pieces
 * @param numTri
 */
PuzzleHandler::PuzzleHandler(int numTri) {
    numPieces = numTri;
}

/**
 * creates the puzzle pieces using the vertices passed in and calculates a random
 * color as well as a random value for both the x's and y's to be translate 
 * outside of the puzzle area
 * @param finalVerts
 */
void PuzzleHandler::makePieces(vec3 finalVerts[])
{
    int count = 6;
    PuzzlePiece* p;
    float randDeltX, randDeltY;
    srand(time(0));
    vec3 c(0.5f, 0.5f, 0.5f);
    int i = 0;
    for(int k = 0; k < numPieces; k++)
    {
        p = new PuzzlePiece(finalVerts[i], finalVerts[i+1], finalVerts[i+2], 0, 0, c);
        triangles.push_back(p);
        i += 3;
    }
    c.x = 0.0f;
    c.y = 0.0f;
    c.z = 0.0f;
    int rgb;
    float colorVal;
    srand(time(0));
    for(int j = numPieces; j < (numPieces * 2); j++)
    {
        //calculates the color of the piece
        colorVal = rand() % 100 + 1;
        colorVal = colorVal/(float)100.0;             
        rgb = rand() % 3;                       
        switch(rgb){
            case 0:
                c.x = colorVal;
                break;
            case 1:
                c.y = colorVal;
                break;
            case 2:
                c.z = colorVal;
                break;
        };
    do{
        //calculates randDeltX and randDeltY so each piece is outside of the
        //puzzle are
            randDeltX = rand() % 190 + 1;
            randDeltX /= 100;
            randDeltY = rand() % 190 + 1;
            randDeltY /= 100;
                    
        }while(  ((((randDeltX + finalVerts[i].x) <= 0)  || ((randDeltX + finalVerts[i+2].x) <= 0)
                || ((randDeltX + finalVerts[i+1].x) <= 0)) && (((randDeltY + finalVerts[i].y) <= 0)
                || ((randDeltY + finalVerts[i+2].y) <= 0) || ((randDeltY + finalVerts[i+1].y) >= 0)))
                || (((randDeltX + finalVerts[i]. x) > 1) || ((randDeltY + finalVerts[i].y) > 1) ||
                ((randDeltX + finalVerts[i+1].x) > 1) || ((randDeltY + finalVerts[i+1].y) > 1) ||
                ((randDeltX + finalVerts[i+2].x) > 1) || ((randDeltY + finalVerts[i+2].y) > 1)) );
        std::cout << "Piece #" << count << endl;
        count++;
        //new puzzle piece is created
        p = new PuzzlePiece(finalVerts[i], finalVerts[i+1], finalVerts[i+2], randDeltX, randDeltY, c);
        //puzzle piece is added to the vector
        triangles.push_back(p);
        i += 3;
    }
    std::cout << "Piece #10 z-value = " << triangles[10]->getZ() << endl;
    std::cout << "Piece #11 z-value = " << triangles[8]->getZ() << endl;

}

/**
 * Description: checks to see if all of the pieces have been solved or not
 * @return Boolean
 */
bool PuzzleHandler::puzzleSolved(){
    for(int i = 0; i < (numPieces * 2); i++)
    {
       if(triangles[i]->getZ() < 0.4)
       {
        if(!(triangles[i]->isSolved()))
        {
           return false;
        }
       }
    }
    playSound();
    return true;
}

/**
 * Description:determines if a puzzle piece has been selected and selects it if 
 * the mouse is within a given piece 
 * @param x, mouse x
 * @param y, mouse y
 * @param tx, delta x
 * @param ty, delta y
 * @return -1 if a piece is not selected
 */
int PuzzleHandler::findSelected(float x, float y, float tx, float ty)
{
    for(int i = 6; i < (numPieces * 2); i++)
    {
        if(triangles[i]->getZ() < 0.4) //this was changed from the original submission
        {
            if(triangles[i]->mouseInPiece(x, y))
            {
                triangles[i]->selected(tx, ty);
                if(triangles[i]->isSolved()){
                    std::cout << "Piece #" << i << " has been solved" << endl;
                }
                return i;
            }
        }
    }
    return -1;
}

/**
 * Description: draws each piece
 * @param s, shader
 */
void PuzzleHandler::drawPieces(Shader* s)
{
    for(int i = 0; i < (numPieces * 2); i++)
    {
        triangles[i]->draw(s);
    }
}

void PuzzleHandler::playSound()
{
    sf::Clock clock;
    sf::Music m;
    m.openFromFile("nervous.wav");
    m.setVolume(100.0);
    m.play();
    while(clock.getElapsedTime().asSeconds() < m.getDuration().asSeconds());
    clock.restart();
}