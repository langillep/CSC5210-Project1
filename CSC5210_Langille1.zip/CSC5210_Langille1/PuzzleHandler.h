/* 
 * File:   PuzzleHandler.h
 * Author: patricklangille
 *
 * Created on September 27, 2017, 8:05 PM
 */

#ifndef PUZZLEHANDLER_H
#define PUZZLEHANDLER_H

#include <GL/glew.h>
#include <SFML/Graphics.hpp>
#include <SFML/OpenGL.hpp>
#include <glm/vec3.hpp>
#include <ctime>
#include "Shader.hpp"
#include "PuzzlePiece.h"
#include <vector>


using glm::vec3;
using glm::vec4;

class PuzzlePiece;

class PuzzleHandler {
public:
    PuzzleHandler(int); //initializes the number of pieces in the puzzle
    void makePieces(vec3[]);//creates each piece
    bool puzzleSolved();//checks to see if each piece has been solved
    int findSelected(float, float, float, float);//checks to see if a piece has been selected
    void drawPieces(Shader*);//draws each piece
    void translatePieces(float, float);
    void playSound();
private:
    int numPieces;//number of pieces in the puzzle
    std::vector<PuzzlePiece*> triangles; //each piece in the puzzle

};

#endif /* PUZZLEHANDLER_H */

