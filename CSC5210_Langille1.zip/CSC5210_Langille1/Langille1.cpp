/**
 * Author: Patrick Langille w/ pieces taken from Christopher Stuetzle
 * 
 * Description: Puzzle: when pieces are placed in the correct spot audio will play
 * pieces are highlighted when moved by the user, pieces are randomly placed 
 * and randomly colored. Audio is played when the puzzle is solved
 */

#include <GL/glew.h>
#include <SFML/Graphics.hpp>
#include <SFML/OpenGL.hpp>
#include <iostream>
#include <ctime>
#include <cstdio>
#include <glm/glm.hpp>
#include <cmath>

// Local Utilities Includes
#include "Shader.hpp"
#include "PuzzlePiece.h"
#include "PuzzleHandler.h"
using std::cerr;
using std::endl;
using glm::vec3;
using glm::mat4;

// Some constants (different from book)
const int Triangles = 0; // The index of the "Triangles" vertex array
const int NumVAOs = 1; // The number of vertex array objects (VAOs)
const int ArrayBuffer = 0; // The index of the array buffer (0)
const int NumBuffers = 1;


// Macro to help convert to proper type for buffer offsets
#define BUFFER_OFFSET(i) ((void*)(intptr_t)(i))

// The total number of buffers
const int vPosition = 0;

// The starting index of the vertex position attribute
GLuint VAOs[NumVAOs];

// An array of vertex array objects
GLuint Buffers[NumBuffers]; // An array of buffers

const GLuint NumVertices = 6;
const int numPieceVertVal = 54;
PuzzleHandler* puzzle = new PuzzleHandler(6); //creates a puzzle handler
sf::Vector2i prevPos;
sf::Vector2i curPos;
Shader* s;


/**
 * Description: takes in a float that represents the change in whatever plane is being worked with
 * @param v1,  delta value
 * @param plane,  x or y plane
 * @return the delta converted to GL coordinates for translation purposes
 */
float windToGL(float v1, char plane)
{
    float g = 0;
    if(plane == 'x')
    {
        return v1 / 1450;
    }
    else{
        return v1 / 950;
    }
    return g;
}

/**
 * Description: given a point and converts it to GL coordinates
 * @param x,float  x-value in window coordinates
 * @param y, float y-value in window coordinates
 * @return vec3 a three dimensional coordinate representing the given coordinate in GL coordinates
 */
vec3 toGL(float x, float y, sf::Window& window)
{
    vec3 g;
    g.x = (x - (window.getSize().x / 2.0)) / (window.getSize().x / 2.0);
    g.y = -1 * ((y - (window.getSize().y / 2.0)) / (window.getSize().y / 2.0));
    g.z = 0.0;
    return g;
}


void init()
{
    //initializes both random vertices to (0,0)
    float randV1X = 0, randV1Y = 0, randV2X = 0, randV2Y = 0;
    srand(time(0));
    //sets random vertex1's x-value to a random number between -.1 and -.85
    randV1X = rand() % 80 + 10;
    randV1X /= -100.0;
    do{
    //sets random vertex 2's x-value to a random number between -.05 and -.85
    randV2X = rand() % 80 + 10; 
    randV2X /= -100.0;
    }while(randV1X == randV2X);
    
    //sets random vertex1's y-value to a random number between -.1 and -.85
    randV1Y = rand() % 70 + 10;
    randV1Y /= -100.0;
    do{
    //sets random vertex2's y-value to a random number between -.1 and -.85
        randV2Y = rand() % 70 + 10;
        randV2Y /= -100.0;
    }while(randV1Y == randV2Y);
    
    float minXX; // will track the vertex with the minimum x-value's x
    float minXY; // will track the vertex with the minimum x-value's y
    float maxXX; // will track the vertex with the maximum x-value's x
    float maxXY; // will track the vertex with the maximum x-value's y
    float minYX; // will track the vertex with the minimum y-value's x
    float minYY; // will track the vertex with the minimum y-value's y
    float maxYX; // will track the vertex with the maximum y-value's x
    float maxYY; // will track the vertex with the maximum y-value's y
    bool rand1MinX = false;
    bool rand1MinY = false;
    //calculates which random vertex is the minimum and which is the maximum
    if(randV1X < randV2X)
    {
        minXX = randV1X;
        minXY = randV1Y;
        maxXX = randV2X;
        maxXY = randV2Y;
        rand1MinX = true;
    }
    else
    {
        minXX = randV2X;
        minXY = randV2Y;
        maxXX = randV1X;
        maxXY = randV2Y;
    }
    //calculates which random vertex is the minimum and which is the maximum
    if(randV1Y < randV2Y)
    {
        minYX = randV1X;
        minYY = randV1Y;
        maxYX = randV2X;
        maxYY = randV2Y;
        rand1MinY = true;
    }
    else
    {
        minYX = randV2X;
        minYY = randV2Y;
        maxYX = randV1X;
        maxYY = randV1Y;
    }
    
    //these will hold the coordinates of each corner of the puzzle area
    float TL[3] = {-0.89, -0.05, 0.3};
    float BL[3] = {-0.89, -0.89, 0.3};
    float TR[3] = {-0.05, -0.05, 0.3};
    float BR[3] = {-0.05, -0.89, 0.3};
    
    float T5[3][3];
    float T6[3][3];
    
    //creates the remaining two triangles based on the placements of the random vertices
    if((rand1MinX && rand1MinY) || ((rand1MinX == false ) && (rand1MinY == false)))
    {
        T5[0][0] = TL[0];
        T5[0][1] = TL[1];
        T5[0][2] = TL[2];
        T5[1][0] = randV1X; 
        T5[1][1] = randV1Y;
        T5[2][0] = randV2X;
        T5[2][1] = randV2Y;
        T6[0][0] = BR[0];
        T6[0][1] = BR[1];
        T6[0][2] = BR[2];
        T6[1][0] = randV1X; 
        T6[1][1] = randV1Y;
        T6[2][0] = randV2X;
        T6[2][1] = randV2Y;
    }
    else
    {
        T5[0][0] = BL[0];
        T5[0][1] = BL[1];
        T5[0][2] = BL[2];
        T5[1][0] = randV1X; 
        T5[1][1] = randV1Y;
        T5[2][0] = randV2X;
        T5[2][1] = randV2Y;
        T6[0][0] = TR[0];
        T6[0][1] = TR[1];
        T6[0][2] = TR[2];
        T6[1][0] = randV1X; 
        T6[1][1] = randV1Y;
        T6[2][0] = randV2X;
        T6[2][1] = randV2Y;
    }

    //array of all of the final triangle vertices
    //triangles will be made up of each consecutive three vertices
    vec3 vertVals[numPieceVertVal] = {
        vec3(-0.89, -0.05, 0.5), 
        vec3(-0.89, -0.89, 0.5), 
        vec3(minXX, minXY, 0.5),
        vec3(-0.89, -0.05, 0.5), 
        vec3(-0.05, -0.05, 0.5), 
        vec3(maxYX, maxYY, 0.5),
        vec3(-0.89, -0.89, 0.5), 
        vec3(-0.05, -0.89, 0.5), 
        vec3(minYX, minYY, 0.5),
        vec3(-0.05, -0.05, 0.5), 
        vec3(-0.05, -0.89, 0.5), 
        vec3(maxXX, maxXY, 0.5), // end of first 4 triangles
        vec3(T5[0][0], T5[0][1], 0.5),
        vec3(T5[1][0], T5[1][1], 0.5),
        vec3(T5[2][0], T5[2][1], 0.5),
        vec3(T6[0][0], T6[0][1], 0.5),
        vec3(T6[1][0], T6[1][1], 0.5),
        vec3(T6[2][0], T6[2][1], 0.5),
        vec3(-0.89, -0.05, 0.2), 
        vec3(-0.89, -0.89, 0.2), 
        vec3(minXX, minXY, 0.2),
        vec3(-0.89, -0.05, 0.2), 
        vec3(-0.05, -0.05, 0.2), 
        vec3(maxYX, maxYY, 0.2),
        vec3(-0.89, -0.89, 0.2), 
        vec3(-0.05, -0.89, 0.2), 
        vec3(minYX, minYY, 0.2),
        vec3(-0.05, -0.05, 0.2), 
        vec3(-0.05, -0.89, 0.2), 
        vec3(maxXX, maxXY, 0.2), // end of first 4 triangles
        vec3(T5[0][0], T5[0][1], 0.2),
        vec3(T5[1][0], T5[1][1], 0.2),
        vec3(T5[2][0], T5[2][1], 0.2),
        vec3(T6[0][0], T6[0][1], 0.2),
        vec3(T6[1][0], T6[1][1], 0.2),
        vec3(T6[2][0], T6[2][1], 0.2)
    };
    
    //takes in the vertices above and creates the puzzle pieces
    puzzle->makePieces(vertVals); 

     // Set up the shader
    string shaders[] = {"vertices.vert", "fragments.frag"};
    s = new Shader(shaders, true);

}

// This function handles keyboard and mouse events
void handleEvents(sf::Window& window)
{
    sf::Event event;
    
    int sol;
    float previousX, previousY, curX, curY;
    // While there are still events.
    while (window.pollEvent(event))
    {
        if (event.type == sf::Event::Closed)
        {
            window.close();
        }
        else if (event.type == sf::Event::Resized)
        {
            glViewport(0, 0, event.size.width, event.size.height);
        }
        // Keyboard pressed
        else if (event.type == sf::Event::KeyReleased)
        {
            if (event.key.code == sf::Keyboard::Q)
            {
                window.close();
            } 
        }
        // Mouse clicks
        // If there's mouse input, handle the camera
        if( sf::Mouse::isButtonPressed(sf::Mouse::Left) )
        {
            curPos = sf::Mouse::getPosition(window);
            sol = puzzle->findSelected(toGL(curPos.x, curPos.y, window).x, toGL(curPos.x, curPos.y, window).y, windToGL((curPos.x - prevPos.x), 'x'), windToGL(((curPos.y - prevPos.y) * -1), 'y'));
            
        }
          
    }
    
    prevPos = sf::Mouse::getPosition(window);
}

// Function to draw stuff
void display(sf::Window& window)
{
    while (window.isOpen())
    {
       
        // First, make sure you handle the events
        handleEvents(window);
        
        // Clears the given framebuffer (in this case, color)
        // Could set color to clear to with glClearColor, default is black
        // Where should we put a call to clearColor?
        glClear(GL_COLOR_BUFFER_BIT);

        // Same as in init, we want to use the Triangles vertex array object
        glBindVertexArray(VAOs[Triangles]);

        // Draw routine, send vertex array to OpenGL rendering pipeline
         //Draw triangles, starting at offset = 0, and going to NumVertices
        //What happens when mode is changed?
        glDrawArrays(GL_TRIANGLES, 0, NumVertices);

        puzzle->puzzleSolved();
        puzzle->drawPieces(s);
        
        // Force OpenGL commands to begin execution
         glBindVertexArray(0);
        window.display();
        
        
    }
}

int main(int argc, char* argv[])
{
    // Need ContextSettings object to set window settings
    sf::ContextSettings settings;   
    settings.antialiasingLevel = 8;

    // Create a new SFML window
    sf::Window window(sf::VideoMode(1000, 800),
            "Pat's Puzzle", sf::Style::Default, settings);

    // To be safe, we’re using glew’s experimental stuff.
    glewExperimental = GL_TRUE;
    // Initialize and error check GLEW
    GLenum err = glewInit();
    if (GLEW_OK != err)
    {
        // If something went wrong, print the error message
        fprintf(stderr, "Error: %s\n", glewGetErrorString(err));
    }

    init();

    display(window);
    

    return 0;
}