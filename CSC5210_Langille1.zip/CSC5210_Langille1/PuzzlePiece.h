/* 
 * File:   PuzzlePiece.h
 * Author: patricklangille
 *
 * Created on September 26, 2017, 11:43 PM
 */

#ifndef PUZZLEPIECE_H
#define PUZZLEPIECE_H

#include <GL/glew.h>
#include <SFML/Graphics.hpp>
#include <SFML/OpenGL.hpp>
#include <glm/vec3.hpp>
#include "Shader.hpp"
#include "PuzzleHandler.h"
#include <cmath>
#include <SFML/Audio.hpp>

using glm::vec3;
using glm::vec4;

class PuzzlePiece {
public:
    PuzzlePiece();//empty constructor
    PuzzlePiece(vec3, vec3, vec3, float, float, vec3);//initializes the puzzle piece
    void setColor(vec3);//sets the color to the given one
    void draw(Shader*);//draws the piece
    void setSolvedGL();//sets back in z-plane
    bool isSolved();//checks to see if the piece has been put in the correct location
    void selected(float, float);//highlights piece
    bool mouseInPiece(float, float);//checks to see if the mouse is in the piece
    float dist(vec3, vec3);//calculates the distance between two points
    void translate(float, float);//moves all vertices of the piece by the same x and y values
    float getZ();
    void playSound();
private:
    vec3 a; //vertex a
    vec3 b; //vertex b
    vec3 c; //vertex b
    vec3 finalA; // vertex a's final placement
    vec3 finalB; // vertex b's final placement
    vec3 finalC; // vertex c's final placement
    bool solved; // whether or not the piece has been put in the correct place
    // The VAO and VBO
    GLuint VAO;
    GLuint VBO;
    
    // The color of the triangle
    vec3 col;
    vec3 highlight;
    float minX, minY, maxX, maxY;


};

#endif /* PUZZLEPIECE_H */

