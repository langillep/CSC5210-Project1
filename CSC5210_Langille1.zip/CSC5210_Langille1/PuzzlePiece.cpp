/* 
 * File:   PuzzlePiece.cpp
 * Author: patricklangille
 * 
 * Created on September 26, 2017, 11:43 PM
 */

#include "PuzzlePiece.h"

PuzzlePiece::PuzzlePiece(){
}

/**
 * Description: constructor for PuzzlePiece
 * @param _a, vertex A (final position)
 * @param _b, vertex B (final position)
 * @param _c, vertex C (final position)
 * @param rx, random value to translate piece's x-values
 * @param ry, random value to translate piece's y-values
 * @param colour, color of the piece
 */
PuzzlePiece::PuzzlePiece(vec3 _a, vec3 _b, vec3 _c, float rx, float ry, vec3 colour) 
{
    solved = false; //the piece is not solved
    finalA = _a;
    finalB = _b;
    finalC = _c;
    a = finalA;
    b = finalB;
    c = finalC;
    col = colour;
    highlight = colour;
    translate(rx, ry); //translates the piece outside of the puzzle area
    //gets midpoint of each side
    if(a.x <= b.x && a.x <= c.x){
        minX = a.x;
    }
    else if(b.x <= c.x){
        minX = b.x;
    }
    else{
        minX = c.x;
    }
    if(a.x >= b.x && a.x >= c.x){
        maxX = a.x;
    }
    else if(b.x >= c.x){
        maxX = b.x;
    }
    else{
        maxX = c.x;
    }
    
    if(a.y <= b.y && a.y <= c.y){
        minY = a.y;
    }
    else if(b.y <= c.y){
        minY = b.y;
    }
    else{
        minY = c.y;
    }
    if(a.y >= b.y && a.y >= c.y){
        maxY = a.y;
    }
    else if(b.y >= c.y){
        maxY = b.y;
    }
    else{
        maxY = c.y;
    }
    std::cout << "a = " << a.x << ", " << a.y << ", " << a.z << endl;
    std::cout << "b = " << b.x << ", " << b.y << ", " << b.z << endl;
    std::cout << "c = " << c.x << ", " << c.y << ", " << c.z << endl;
    std::cout << "minx = " << minX << " maxX = " << maxX << " miny = " << minY << " maxY = " << maxY << endl;

}

//sets the current color to the given one
void PuzzlePiece::setColor( vec3 newCol ) {
    col = newCol;
}

// The draw function
void PuzzlePiece::draw(Shader* s)
{
     GLfloat verts[] = {a.x, a.y, a.z, b.x, b.y, b.z, c.x, c.y, c.z};
   
    // Set up the VBO
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);

    glBindVertexArray(VAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);

    glBufferData(GL_ARRAY_BUFFER, sizeof (verts), verts, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(0);
    glBindVertexArray(VAO);

    // Make the color red
    GLint c = s -> GetVariable("color");
    s -> SetVector3(c, 1, &col[0]);
    glDrawArrays(GL_TRIANGLES, 0, 3);

    // Switch to blue for the outline
    s -> SetVector3(c, 1, &highlight[0]);
    glDrawArrays(GL_LINE_LOOP, 0, 3);

    glBindVertexArray(0);
    highlight = col;

}
 
/**
 * Description: sets the puzzle piece to its solved position (locked)
 */
void PuzzlePiece::setSolvedGL()
{
   // currentPosGL = finalPosGL;
    a = vec3(finalA.x, finalA.y, 0.4);
    b = vec3(finalB.x, finalB.y, 0.4);
    c = vec3(finalC.x, finalC.y, 0.4);
    solved = true;
    playSound();
    std::cout << "piece is locked" << endl;
    std::cout << "a = " << a.x << ", " << a.y << ", " << a.z << endl;
    std::cout << "b = " << b.x << ", " << b.y << ", " << b.z << endl;
    std::cout << "c = " << c.x << ", " << c.y << ", " << c.z << endl;
    
}

/**
 * Description: checks piece based on position and whether, or not, it has already 
 * been determined, and determines if the piece has been solved
 * @return 
 */
bool PuzzlePiece::isSolved()
{
    //checks to see if the current xs and ys are close to the final vertex values
    float difX = a.x - finalA.x;
    float difY = a.y - finalA.y;
    if(difY < 0){
        difY *= -1.0f;
    }
    if(difX < 0){
        difX *= -1.0f;
    }
    if(solved == false && difX < 0.01f && difY < 0.01f)
    {
        solved = true;
        setSolvedGL();
    }
    return solved;
}


/**
 * Description: translates the piece and highlights it
 * @param x, change in x
 * @param y, change in y
 */
void PuzzlePiece::selected(float x, float y)
{
    if(!solved){
        highlight = vec3(0.75, 0.75, 0.0);
        translate(x, y);  
    }
}

/**
 * Description: determines if the mouse's coordinates are within the bounding box
 * @param mX
 * @param mY
 * @return 
 */
bool PuzzlePiece::mouseInPiece(float mX, float mY)
{
    return (mX < maxX && mX > minX && mY > minY && mY < maxY);
}


/**
 * Description: calculates the distance between two points
 * @param v1
 * @param v2
 * @return 
 */
float PuzzlePiece::dist(vec3 v1, vec3 v2)
{
    return sqrt(pow((v2.x - v1.x), 2) + pow((v2.y - v1.y), 2));
}

/**
 * Description: translates the puzzle piece by a given x amount and y amount
 * @param deltx, value translated  along x-axis
 * @param delty, value translated along y-axis
 */
void PuzzlePiece::translate(float deltx, float delty)
{
    if(a.z < 0.4) // changed from original submission
    {
    a.x = a.x + (deltx);
    a.y = a.y + (delty);
    b.x = b.x + (deltx);
    b.y = b.y + (delty);
    c.x = c.x + (deltx);
    c.y = c.y + (delty);
    maxX = maxX + deltx;
    maxY = maxY + delty;
    minX = minX + deltx;
    minY = minY + delty;
    }
}

/**
 * Description: since all z values for a given puzzle piece will be the same,
 * this will be used to check if the piece is set back in the z-plane
 * @return z-value
 */
float PuzzlePiece::getZ()
{
    return a.z;
}

void PuzzlePiece::playSound()
{
    sf::Clock clock;
    sf::Music m;
    m.openFromFile("computer_mercy.wav");
    m.setVolume(100.0);
    m.play();
    while(clock.getElapsedTime().asSeconds() < m.getDuration().asSeconds());
    clock.restart();
}